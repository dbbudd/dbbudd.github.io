/*:
 Modify the `goForward()` function below to allow you to pass the parameters `speed` and `time`.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    def goForward(){
        move(speed: 100)
        wait(time: 1)
        stop()
    }
    
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code


