/*:
 Create a function called `ambulance()`.  The function should turn your mBot into an ambulance with lights and sound.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    func ambulance(){
        
    }
    
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code
