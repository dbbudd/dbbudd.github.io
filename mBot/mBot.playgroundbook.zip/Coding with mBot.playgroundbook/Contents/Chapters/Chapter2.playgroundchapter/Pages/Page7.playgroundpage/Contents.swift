/*:
 Modify the code below to allow the mBot to travel in a triangle. You should also do a loop.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    func goForward(){
        
    }
    
    func turnLeft(){
        
    }
    
    func triangle(){
        goForward()
        turnLeft()
    }
    
    triangle()
    
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code


