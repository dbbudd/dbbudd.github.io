/*:
 Create a function called `blink()` which utilises parameters.  The function to turn the lights red for 1 second and then white.  This sequence should then be repeated multiple time.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    func blink(){
        
    }
    
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code
