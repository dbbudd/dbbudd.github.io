/*:
 Functions are used to create a block of sequenced steps which are frequently used.  Create function for `goForward()`.  When mBot goes forward it should turn both lights to green, they should turn red when it goes backwards.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    func goForward(){
        
    }
    
    goForward()
    
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code


