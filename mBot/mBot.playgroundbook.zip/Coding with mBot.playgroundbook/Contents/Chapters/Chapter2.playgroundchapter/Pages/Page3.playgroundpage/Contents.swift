/*:
 Once your function has been created you can then call it multiple times using the defined name.  Call the `goForward()` function below the function declaration.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    func goForward(){
        move(speed: 100)
        wait(time: 1)
        stop()
    }
    
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code



