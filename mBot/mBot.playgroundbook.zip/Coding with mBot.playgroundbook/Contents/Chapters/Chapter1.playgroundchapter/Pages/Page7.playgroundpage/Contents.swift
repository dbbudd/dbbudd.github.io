/*:
 Using the `lightLeft()`, `lightRight()` and `lightBoth()` - sequence your functions so that your mBot appears to have indicators.  When it stops both lights should shine red.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code
