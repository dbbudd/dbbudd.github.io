/*:
Placing a negative number in the `move()` function will make the motors spin the opposite way.
*/
//#-hidden-code

execiseCode = {
    
//#-end-hidden-code
//#-editable-code
    move(speed: 100)
    wait(time: 1)
    move(speed: 0)
//#-end-editable-code
//#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code
