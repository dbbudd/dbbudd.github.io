/*:
 Use the beep functions beep functions below to sing a different tune depending on the direction turned.
 */
//#-hidden-code

execiseCode = {
    
    //#-end-hidden-code
    //#-editable-code
    beepDo()
    beepMi()
    beepSol()
    beepDo()
    //#-end-editable-code
    //#-hidden-code
    
}

runWithCommands()

//#-end-hidden-code
