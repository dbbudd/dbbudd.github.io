//
//  MBot.swift
//  MakeblockPlaygrounds
//
//  Created by CatchZeng on 2016/12/19.
//  Copyright © 2016年 makeblock. All rights reserved.
//

import Foundation

public class MBot: MakeblockRobot{
    
    public override init(connection: Connection){
        super.init(connection: connection)
    }
}
