//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Swift has a couple different Collection Types, but we are going to focus on Arrays.  An array stores values of the same type in an ordered list. The same value can appear in an array multiple times at different positions.
//:
//#-editable-code Tap to enter code
//declare a blank list of numbers (Integers)
var list = [Int]()
for _ in 1...5{
    let number = random(range: 100)
    //add our random number to the list
    list.append(number)
}
//#-end-editable-code
//: Once we have our list we can print out the items individually
//#-editable-code Tap to enter code
for number in list{
    show(number)
}
//#-end-editable-code
//: ... or we can print out the entire list by converting it to a String.
//#-editable-code Tap to enter code
show(String(describing: list))
//#-end-editable-code
