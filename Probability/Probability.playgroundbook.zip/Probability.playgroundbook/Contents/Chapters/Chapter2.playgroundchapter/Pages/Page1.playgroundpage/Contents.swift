//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Computers are very good at performing repetative tasks. Where you and I would get bored easily flipping a coin over and over again a computer would go all day ... and then some. There are two commands we use in Swift to tell our program to repeat itself. Both methods essentially do the same thing but there are slight differences.
//:
//: The first one we will explore is a fixed-length loop. This is used when we know how many times we want to repeat our program.
//#-editable-code Tap to enter code
for i in 0...10{
    show(i)
}
//#-end-editable-code
//: The above `for-loop` iterates (loops) over a range a set number of times.  In this case we have told it to iterate 10 times, each time it goes through the cycle it is outputing the number so you can see how it works.
//:
//: We could also make it draw 5 random numbers between, 1 and 100.  You'll notice that the letter 'i' is replaced with an underscore.  This is because I'm not using the 'i' in the loop so it doens't need to be referenced.
//#-editable-code Tap to enter code
for _ in 1...5{
    show(random(range: 100))
}
//#-end-editable-code

