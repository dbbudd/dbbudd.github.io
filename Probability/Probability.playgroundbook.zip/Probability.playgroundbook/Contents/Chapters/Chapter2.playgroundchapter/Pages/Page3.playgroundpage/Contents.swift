//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Create a program which simulates a space shuttle launch count down.  You can choose which type of loop you wish to use.

//#-editable-code Tap to enter code
show("Initiate launch sequence!")
show("...")
show("Blast off!!")
//#-end-editable-code
