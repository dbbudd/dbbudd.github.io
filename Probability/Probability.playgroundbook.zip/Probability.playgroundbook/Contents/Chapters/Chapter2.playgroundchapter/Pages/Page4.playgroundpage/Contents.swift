//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Now that you have exposure to loops and generating random numbers. Write a program which will simulate rolling a 6 sided dice 50 times. How many times does the number 4 come up? Is it more or less then 20% of the time?
//: 
//#-editable-code Tap to enter code
//#-end-editable-code
