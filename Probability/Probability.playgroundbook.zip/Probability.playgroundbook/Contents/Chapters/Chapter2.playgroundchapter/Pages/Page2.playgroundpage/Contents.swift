//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: The second time of loop is called a while loop. A while loop starts by evaluating a single condition. If the condition is true, a set of statements is repeated until the condition becomes false.
//#-editable-code Tap to enter code
var diceRoll = 0
while diceRoll < 6{
    // roll the dice
    diceRoll = random(range: 6)
    show(diceRoll)
}
show("Game Over!!!")
//#-end-editable-code
//: The above example shows a very simple program which will keep looping until the dice value is 6.

