//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Write a program which will simulate rolling a 10-sided dice, 50 times. Each time the dice is rolled it must be added to the list.
//:
//#-editable-code Tap to enter code
var list = [Int]()
//#-end-editable-code
