//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()

import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Write a program to simulate flipping a coin 50 times and plot the results of the tests on a Scatter Graph.
//#-editable-code Tap to enter code.
//#-end-editable-code


