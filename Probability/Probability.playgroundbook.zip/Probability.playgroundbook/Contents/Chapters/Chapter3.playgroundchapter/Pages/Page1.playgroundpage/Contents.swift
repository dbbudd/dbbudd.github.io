//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()

import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}

//#-end-hidden-code
//: Graphs allow us to visualise data easier and recognise patterns.  The below code counts how many times a particular number is rolled by the 6-sided dice.  Run the code and see if one particular number is favoured in the 100 times the dice are rolled.
//#-editable-code Tap to enter code.
var count1 = 0.0
var count2 = 0.0
var count3 = 0.0
var count4 = 0.0
var count5 = 0.0
var count6 = 0.0

for _ in 1...100{
    let number = random(range: 6)
    if number == 1{
        count1 += 1
    }
    else if number == 2{
        count2 += 1
    }
    else if number == 3{
        count3 += 1
    }
    else if number == 4{
        count4 += 1
    }
}

let line = LinePlot(yData: 0, count1, count2, count3, count4)
//#-end-editable-code

//: Modify the code above to also count when a 5 or 6 is rolled.
//#-editable-code Tap to enter code.
let average = Double((count1 + count2 + count3 + count4 + count5 + count6) / 6)
let avgFunction = LinePlot{x in average}

avgFunction.lineWidth = 3
//#-end-editable-code

//: The snippet of code above calculates the average of the frequencies and plots a line on our Graph.
