//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()

import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Graphs allow us to visualise data easier and recognise patterns.  The below code simulates the rolling of two dice, 20 times.  The rolls are stored in lists and the results plotted.  How many times is the same number rolled on each dice?
//#-editable-code Tap to enter code.
//create two empty lists
var list1 = XYData()
var list2 = XYData()

//begin simulation
for testNo in 1...20{
    //create dice
    let dice1 = random(range: 6)
    let dice2 = random(range: 6)
    
    //"testNo" is number test and the y value is the dice roll.
    list1.append(x: Double(testNo), y: Double(dice1))
    list2.append(x: Double(testNo), y: Double(dice2))
}

//create a line plot
let line1 = ScatterPlot(xyData: list1)
let line2 = ScatterPlot(xyData: list2)
//#-end-editable-code

//: Modify the code above to roll a 10-sided dice, 50 times. Do you notice any change in the patterns?


