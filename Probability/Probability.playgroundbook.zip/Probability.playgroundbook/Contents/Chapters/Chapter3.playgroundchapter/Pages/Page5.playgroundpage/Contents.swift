//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()

import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Write a program to simulate flipping a coin 200 times and record how many times it lands on heads or tails.  Plot the results on a Scatter Graph.
//#-editable-code Tap to enter code.
//#-end-editable-code


