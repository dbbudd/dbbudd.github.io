//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()

import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//#-editable-code Tap to enter code.
let line = LinePlot(yData: 0, 1, 4, 9, 16)
line.label = "Squares of Numbers"
//#-end-editable-code

//: You can modify the line thickness with the following line of code.  See if you can figure out how to change the colour of the line.
//#-editable-code Tap to enter code.
line.lineWidth = 3
//#-end-editable-code
