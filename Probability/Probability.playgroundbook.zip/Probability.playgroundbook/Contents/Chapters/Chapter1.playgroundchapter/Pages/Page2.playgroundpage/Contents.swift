//#-code-completion(identifier, hide, setupLiveView())
//: When you talk, you need to follow certain rules to be understood, called the grammar or syntax of the language.  You can't just use any words whenever you like... it wouldn't make sense!
//:
//: Maths has syntax too.  If you saw an equation which was expressed as; "53 + / 10", you would be super confused because the syntax isn't correct.  Well programming languages have syntax as well.  Swift is pretty easy to learn because it has very simple syntax.as
//:
//: Traditionally, the first program you write when learning a new programming language is 'Hello, World!'.
//: Let's write it in Swift now...
//:
//#-hidden-code
import Foundation
//#-end-hidden-code

show("Hello, World!")


//: Modify the code below to say 'hello' to yourself.

//#-editable-code Tap to enter code
show("Hello, World!")
//#-end-editable-code

