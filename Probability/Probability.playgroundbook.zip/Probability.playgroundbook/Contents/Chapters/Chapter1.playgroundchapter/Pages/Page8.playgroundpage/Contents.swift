//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: What's the biggest number you can think of? I bet I can think of one twice as big! I bet I can think of one twice as big! I'll just double yours! No matter how big your number is, there's always another one twice a big! Write a program which doubles the number.

//#-editable-code Tap to enter code
let number = 8
show(number)
//#-end-editable-code
