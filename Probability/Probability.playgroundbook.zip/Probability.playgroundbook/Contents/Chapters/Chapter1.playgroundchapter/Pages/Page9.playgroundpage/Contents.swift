//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: As a part of our probability simulations we will need to randomly call numbers.  To do this we have a special function called `random()`.
//#-editable-code Tap to enter code
let number = random(range: 10)
show(number)
//#-end-editable-code
//: You'll notice that this function is slightly different to the other functions you have been using.  It has an extra word in the brackets.  This is called a parameter and tells the programmer exactly what is being placed into the function. 
//: Our `random()` function above has the parameter name as `range` and then the value of 10 placed in the function.  This will give us a random number between 1 and 10.
//:
//: Once you get into coding more you'll start writing your own functions which will sort numbers, pull random numbers and all sorts of other things, but for now you need to write a program which will call two random numbers between 1 and 10, and then add them together.
//#-editable-code Tap to enter code
//#-end-editable-code
