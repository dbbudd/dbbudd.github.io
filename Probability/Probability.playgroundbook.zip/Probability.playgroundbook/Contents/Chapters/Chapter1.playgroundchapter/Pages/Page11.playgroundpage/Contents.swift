//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Using the `random()` function write a program which will simulate rolling a six sided dice.
//#-editable-code Tap to enter code
//#-end-editable-code
