//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: Swift cand o all the operations you expect from a calculator; Addition (+), Subtraction (-), Multiplication (*), Division (/).
//:
//: It uses the correct order of operations, so it will do multiplication and division before addition and subtraction, except if you use brackets.
//:
//: Let's calculate the hours in a leap year.

//#-editable-code Tap to enter code
let hours_leap_year = (365 + 1) * 24
show(hours_leap_year)
//#-end-editable-code

//: Run it, then try again without the brackets.  What happens?
