//: Maths and computing go hand in hand.  Computers were first invented to do maths quickly, but computers wouldn't exist without maths. Everything on your iPad screen uses lots of maths, including number systems, algebra, equations, and geometry - all things you learnt about in Year 7.
//:
//: This playground book is a companion course to the Probability with Swift multi-touch resource and assumes that you have a basic knowledge of programming.  The book will give you context for the activities that we are about to complete.
//:
//: So let's get started... edit the code below so it will display your name instead of the famous Probability Mathematician "Blaise Pascal".
//:
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//#-editable-code Tap to enter code

let name = "Blaise Pascal"

show("Hi " + name)

//#-end-editable-code

