//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: If there's one thing computers are really good at, it's working with numbers. They can do billions of calculations per second! Speaking of seconds, let's calculate the number of second in a day.
//: * `60 secs per min x 60 mins per hour x 24 hours per day`
//: In Swift, numbers are numbers, and multiplication is `*` (asterisk):
show(60 * 60 * 24)
//: Swift, like most programming languages, uses `*` for multiplication because `x` is a variable name. Try calculating the number of seconds in a year!
//#-editable-code Tap to enter code
//#-end-editable-code
