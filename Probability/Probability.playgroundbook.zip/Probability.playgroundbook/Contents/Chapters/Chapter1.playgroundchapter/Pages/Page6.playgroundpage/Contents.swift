//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: Swift is much better than a calculator, because it has variables!
//: 
//: You can use variables to store numners and calculations for later, and describe what the calculation does very clearly:
//#-editable-code Tap to enter code
let secs_min = 60
let mins_hour = 60
let hours_day = 24
let secs_day = secs_min * mins_hour * hours_day
show(secs_day)
//#-end-editable-code
//: We've followed a consistent variable naming pattern or convention: seconds per minute (`secs_min`), minutes per hour (`mins_hour`), hours per day (`hours_day`), and seconds per day (`secs_day`).  This makes the variable code easier to understand.
