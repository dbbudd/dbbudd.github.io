//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: Writing out long messages many times is a pain.  It would be great if we could just store the message somewhere and reuse it. A variable is a place for storing a value so we can use it later in our program. Each variable has a name which we use to set and get its value. In Swift, we create a new variable using an equal sign.  Now we can write a program to help us practise a hard example:

let example = 11
show(example * 100)
show(example * 200)
show(example * 300)

//: The first statement create a new variable called example (meaning the example we're practising).  We then output the variable three times, each time multipling it by a different number.
//:
//: Create your own example below using a different number.

//#-editable-code Tap to enter code
show("Hello, World!")
//#-end-editable-code
