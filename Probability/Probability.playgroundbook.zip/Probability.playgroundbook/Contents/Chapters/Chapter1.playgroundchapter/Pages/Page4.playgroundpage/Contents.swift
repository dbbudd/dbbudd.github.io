//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: We have now already used a function called `show()`, so we had better tell you what a function actually is!  A function is a named piece code (programmers say call the function) to perform the task without having to know how it works.  In Swift, a function is called by name followed by round brackets.  Some functions take data to perform their tasks the value wants you to output.  THis data goes inside the brackets.

//#-editable-code Tap to enter code
show(10 / 2)
//#-end-editable-code

//: Some functions produce data while performing their task.  For example the function `ask()` produces the string that the user enters.  Programms call this the return value.  It can be used directly or stored in a variable.

//#-editable-code Tap to enter code
let msg = ask("Repeat? ")
show(msg)
show(msg)
//#-end-editable-code
