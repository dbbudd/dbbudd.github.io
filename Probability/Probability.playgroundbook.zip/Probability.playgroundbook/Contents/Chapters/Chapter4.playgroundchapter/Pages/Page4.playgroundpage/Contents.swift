//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation

func random(range: UInt32) -> Int{
    return Int(arc4random_uniform(range) + 1)
}
//#-end-hidden-code
//: Modify the code to make the simulation run 10,000 times. Based on the results obtained so far, what do you think is the average number of cans needed to obtain a complete set?

//#-editable-code Tap to enter code.
var total_tally = 0
var number_of_collections = 0
for _ in 1...10{
    var fish1 = 0
    var fish2 = 0
    var fish3 = 0
    var fish4 = 0
    var fish5 = 0
    var fish6 = 0
    while fish1 <= 0 || fish2 <= 1 || fish3 <= 0 || fish4 <= 0 || fish5 <= 0 || fish6 <= 0 {
        let number = random(range: 6)
        if number == 1{
            fish1 += 1
        }
        if number == 2{
            fish2 += 1
        }
        if number == 3{
            fish3 += 1
        }
        if number == 4{
            fish4 += 1
        }
        if number == 5{
            fish5 += 1
        }
        if number == 6{
            fish6 += 1
        }
    }
    total_tally = total_tally + fish1 + fish2 + fish3 + fish4 + fish5 + fish6
    number_of_collections += 1
    
}

show("Total Tally: " + String(total_tally))
show("Number of Collections: " + String(number_of_collections))

let avg_number_items = total_tally / number_of_collections
show("Avg. Number of Items: " + String(avg_number_items))
//#-end-editable-code

