//: # Create Containers
//: Now we have our data structure setup we need to start setting up our User Interface (UI).  The first step is to create some container views which will hold all of the cards in the hand as they are dealt.
//:
//: There will be two views; One for the `myDealer` and one for the `myPlayer`.
//: * The player will be 490 x 240 and will be position in the coordinates (10,550).  The rectangle with be red with a corner radius of 10 and border width of 0.
//: * The dealer will also be 490 x 240, however, it will be position in the coordinates (10,10).  The rectangle will also be red with a corner radius of 10 and border width of 0.
//:
//#-hidden-code
import PlaygroundSupport
import UIKit

extension Array{
    mutating func shuffle(){
        let length = Int(self.count)
        for _ in 0..<length{
            sort{
                (_,_) in arc4random() < arc4random()
            }
        }
    }
}

struct Deck{
    var cards = ["Hearts01","Hearts02","Hearts03","Hearts04","Hearts05","Hearts06","Hearts07","Hearts08","Hearts09","Hearts10","HeartsJ10","HeartsQ10","HeartsK10","Diamonds01","Diamonds02","Diamonds03","Diamonds04","Diamonds05","Diamonds06","Diamonds07","Diamonds08","Diamonds09","Diamonds10","DiamondsJ10","DiamondsQ10","DiamondsK10","Spades01","Spades02","Spades03","Spades04","Spades05","Spades06","Spades07","Spades08","Spades09","Spades10","SpadesJ10","SpadesQ10","SpadesK10","Clubs01","Clubs02","Clubs03","Clubs04","Clubs05","Clubs06","Clubs07","Clubs08","Clubs09","Clubs10","ClubsJ10","ClubsQ10","ClubsK10"]
    
    init(){
        cards.shuffle()
    }
    
    func countCards() -> Int{
        return cards.count
    }
    
    mutating func hit() -> String{
        return cards.removeFirst()
    }
}

struct Player{
    var hand = Array<String>()
    
    
    func countCards() -> Int{
        return hand.count
    }
    
    func handValue() -> Int{
        var value = 0
        for card in hand{
            value = value + Int(String(card.characters.suffix(2)))!
        }
        return value
    }
}
//#-end-hidden-code

class ViewController: UIViewController{
    let dealerView = UIView()
    let playerView = UIView()
    
    var myDeck: Deck = Deck()
    var myPlayer: Player = Player()
    var myDealer: Player = Player()
    
    override func viewDidLoad(){
        createContainers()
    }
    
    func createContainers(){
        //#-editable-code
        //#-end-editable-code
    }
}
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
