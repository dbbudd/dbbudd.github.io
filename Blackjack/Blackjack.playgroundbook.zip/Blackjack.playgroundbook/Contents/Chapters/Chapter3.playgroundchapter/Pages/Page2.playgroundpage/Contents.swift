//: # Structs
//: Rather than using an array normally we are going to create a Structure, or Structs which will encapsulate related properties and behaviours of our deck of cards.
//:
/*: In the struct below called `Deck` you can see that we have a property called `cards` which contains our array of cards, we have an initialising method which shuffles the array and we have two other methods (`countCards()` and `hit()`).  The struct is defined outside of the main view controller and the new instance of the Deck object is defined inside the view controller.  When the object is created the `init()` method is called automatically.  This means our cards will be shuffled straight away and we can begin to start dealing cards.
*/
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

extension Array{
    mutating func shuffle(){
        let length = Int(self.count)
        for _ in 0..<length{
            sort{
                (_,_) in arc4random() < arc4random()
            }
        }
    }
}
//#-end-hidden-code

struct Deck{
    var cards = ["Hearts01","Hearts02","Hearts03","Hearts04","Hearts05","Hearts06","Hearts07","Hearts08","Hearts09","Hearts10","HeartsJ10","HeartsQ10","HeartsK10","Diamonds01","Diamonds02","Diamonds03","Diamonds04","Diamonds05","Diamonds06","Diamonds07","Diamonds08","Diamonds09","Diamonds10","DiamondsJ10","DiamondsQ10","DiamondsK10","Spades01","Spades02","Spades03","Spades04","Spades05","Spades06","Spades07","Spades08","Spades09","Spades10","SpadesJ10","SpadesQ10","SpadesK10","Clubs01","Clubs02","Clubs03","Clubs04","Clubs05","Clubs06","Clubs07","Clubs08","Clubs09","Clubs10","ClubsJ10","ClubsQ10","ClubsK10"]
    
    init(){
        cards.shuffle()
    }
    
    func countCards() -> Int{
        return cards.count
    }
    
    mutating func hit() -> String{
        return cards.removeFirst()
    }
}

//: The idea is that we setup a data structure which could be reused without duplication.  For example we could have a game which used two decks of cards without copying and pasting the array of cards.
//:
//: Your first task is to complete the struct called `Player` with the following definitions:
//: 1. a property called `hand` which is an Array of Strings
//: 2. a method called `countCards()` which returns an `Int`.  The return statement will be `hand.count`
//:
//: Inside the view controller `myPlayer` and `myDealer` have already been initialised using the struct you are about to create.
//:

struct Player{
    //#-editable-code
    //#-end-editable-code
}


class ViewController: UIViewController{
    
    var myDeck: Deck = Deck()
    var myPlayer: Player = Player()
    var myDealer: Player = Player()
    
    override func viewDidLoad(){
        
    }
}


//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
