//: # Create Cards
//: Next we need to create our cards which will be displayed inside the respective views.  Just like in our previous project a card is a UIImageView().  To switch between the player and dealer a value called player is passed which is either a 1 or a 0.  We have also defined a global `x` position for the player and dealer so the cards don't stack on top of each other.  These are called `pCardXPos` and `dCardXPos`.
//: 1. If the player value is equal to 0, add 30 to the `pCardXPos`, create the frame dimensions of the img with the values 83 x 121. Ensure you add the img to the correct subview.
//: 2. If the player value is equal to 1, add 30 to the `dCardXPos`, create the frame dimensions of the img with the values 83 x 121. Ensure you add the img to the correct subview.
//#-hidden-code
import PlaygroundSupport
import UIKit

extension Array{
    mutating func shuffle(){
        let length = Int(self.count)
        for _ in 0..<length{
            sort{
                (_,_) in arc4random() < arc4random()
            }
        }
    }
}

struct Deck{
    var cards = ["Hearts01","Hearts02","Hearts03","Hearts04","Hearts05","Hearts06","Hearts07","Hearts08","Hearts09","Hearts10","HeartsJ10","HeartsQ10","HeartsK10","Diamonds01","Diamonds02","Diamonds03","Diamonds04","Diamonds05","Diamonds06","Diamonds07","Diamonds08","Diamonds09","Diamonds10","DiamondsJ10","DiamondsQ10","DiamondsK10","Spades01","Spades02","Spades03","Spades04","Spades05","Spades06","Spades07","Spades08","Spades09","Spades10","SpadesJ10","SpadesQ10","SpadesK10","Clubs01","Clubs02","Clubs03","Clubs04","Clubs05","Clubs06","Clubs07","Clubs08","Clubs09","Clubs10","ClubsJ10","ClubsQ10","ClubsK10"]
    
    init(){
        cards.shuffle()
    }
    
    func countCards() -> Int{
        return cards.count
    }
    
    mutating func hit() -> String{
        return cards.removeFirst()
    }
}

struct Player{
    var hand = Array<String>()
    
    
    func countCards() -> Int{
        return hand.count
    }
    
    func handValue() -> Int{
        var value = 0
        for card in hand{
            value = value + Int(String(card.characters.suffix(2)))!
        }
        return value
    }
}
//#-end-hidden-code

class ViewController: UIViewController{
    
    let dealerView = UIView()
    let playerView = UIView()
    var pCardXPos = 60
    var dCardXPos = 60
    let pLabel = UILabel()
    let dLabel = UILabel()
    
    var myDeck: Deck = Deck()
    var myPlayer: Player = Player()
    var myDealer: Player = Player()
    
    override func viewDidLoad(){
        var myDeck: Deck = Deck()
        
        var myPlayer: Player = Player()
        var myDealer: Player = Player()
        
        createContainers()
        createLabel()
    }
    //#-hidden-code
    func createLabel(){
        pLabel.frame = CGRect(x:10, y:500, width: 490, height:50)
        pLabel.text = "Player's Value: " + String(myPlayer.handValue())
        self.view.addSubview(pLabel)
        
        dLabel.frame = CGRect(x:10, y:240, width: 490, height:50)
        dLabel.text = "Dealer's Value: " + String(myDealer.handValue())
        self.view.addSubview(dLabel)
    }
    
    func createContainers(){
        dealerView.frame = CGRect(x:10, y:10, width:490, height:240)
        dealerView.backgroundColor = UIColor.red
        dealerView.layer.cornerRadius = 25
        dealerView.layer.borderWidth = 0
        self.view.addSubview(dealerView)
        
        playerView.frame = CGRect(x:10, y:550, width:490, height:240)
        playerView.backgroundColor = UIColor.red
        playerView.layer.cornerRadius = 25
        playerView.layer.borderWidth = 0
        self.view.addSubview(playerView)
    }
    //#-end-hidden-code
    
    func createCard(player:Int, image:String, xPos: Int, yPos: Int){
        let img = UIImageView()
        img.image = UIImage(named: image)
        if player == 0{
            //#-editable-code
            //#-end-editable-code
        } else {
            //#-editable-code
            //#-end-editable-code
        }
    }
}
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
