//: # Project Introduction
//: For this next project we are going to create a very simple version of Blackjack a.k.a. 21. The rules won't be strictly correct, but the simple functionality will allow you to apply what you have learnt so far.
//:
//: We will be using a similar deck of cards arranged in an Array as we did in the previous project.  This will allow us to keep order using the index of the Array.
//:

var cards = ["Hearts01","Hearts02","Hearts03","Hearts04","Hearts05","Hearts06","Hearts07","Hearts08","Hearts09","Hearts10","HeartsJ10","HeartsQ10","HeartsK10","Diamonds01","Diamonds02","Diamonds03","Diamonds04","Diamonds05","Diamonds06","Diamonds07","Diamonds08","Diamonds09","Diamonds10","DiamondsJ10","DiamondsQ10","DiamondsK10","Spades01","Spades02","Spades03","Spades04","Spades05","Spades06","Spades07","Spades08","Spades09","Spades10","SpadesJ10","SpadesQ10","SpadesK10","Clubs01","Clubs02","Clubs03","Clubs04","Clubs05","Clubs06","Clubs07","Clubs08","Clubs09","Clubs10","ClubsJ10","ClubsQ10","ClubsK10"]

//: [Previous](@previous)  ||  [Next Topic](@next)
