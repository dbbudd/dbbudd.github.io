//: # Methods
//: On our `Player` struct we need one more method called `handValue()` this method will go through all the cards in the players hand and return an integer.  Remember that the cards are stored as an array of strings (e.g. "DiamondsJ10") so you will need to get the last two characters from the string and convert them to an integer.  If you can't remember how to do this go back through the previous activities in the "Cards" section.
//:

//#-hidden-code

import PlaygroundSupport
import UIKit

extension Array{
    mutating func shuffle(){
        let length = Int(self.count)
        for _ in 0..<length{
            sort{
                (_,_) in arc4random() < arc4random()
            }
        }
    }
}


struct Deck{
    var cards = ["Hearts01","Hearts02","Hearts03","Hearts04","Hearts05","Hearts06","Hearts07","Hearts08","Hearts09","Hearts10","HeartsJ10","HeartsQ10","HeartsK10","Diamonds01","Diamonds02","Diamonds03","Diamonds04","Diamonds05","Diamonds06","Diamonds07","Diamonds08","Diamonds09","Diamonds10","DiamondsJ10","DiamondsQ10","DiamondsK10","Spades01","Spades02","Spades03","Spades04","Spades05","Spades06","Spades07","Spades08","Spades09","Spades10","SpadesJ10","SpadesQ10","SpadesK10","Clubs01","Clubs02","Clubs03","Clubs04","Clubs05","Clubs06","Clubs07","Clubs08","Clubs09","Clubs10","ClubsJ10","ClubsQ10","ClubsK10"]
    
    init(){
        cards.shuffle()
    }
    
    func countCards() -> Int{
        return cards.count
    }
    
    mutating func hit() -> String{
        return cards.removeFirst()
    }
}

//#-end-hidden-code

struct Player{
    var hand = Array<String>()
    
    
    func countCards() -> Int{
        return hand.count
    }
    
    func handValue() -> Int{
        //#-editable-code
        //#-end-editable-code
    }
}

class ViewController: UIViewController{
    override func viewDidLoad(){
        var myDeck: Deck = Deck()
        
        var myPlayer: Player = Player()
        var myDealer: Player = Player()
    }
}

//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
