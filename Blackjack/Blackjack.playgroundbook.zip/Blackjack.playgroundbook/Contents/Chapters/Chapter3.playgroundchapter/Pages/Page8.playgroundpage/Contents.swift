//: # "Hit" Action
//: The Hit Button calls a function called `hitAction` when the user touches it.  We need to create the actions for this button so that a card will be created and the card will be added to the players hand. The players card has been created when the Hit Button is pressed but we need the same action
//#-hidden-code
import PlaygroundSupport
import UIKit

extension Array{
    mutating func shuffle(){
        let length = Int(self.count)
        for _ in 0..<length{
            sort{
                (_,_) in arc4random() < arc4random()
            }
        }
    }
}

struct Deck{
    var cards = ["Hearts01","Hearts02","Hearts03","Hearts04","Hearts05","Hearts06","Hearts07","Hearts08","Hearts09","Hearts10","HeartsJ10","HeartsQ10","HeartsK10","Diamonds01","Diamonds02","Diamonds03","Diamonds04","Diamonds05","Diamonds06","Diamonds07","Diamonds08","Diamonds09","Diamonds10","DiamondsJ10","DiamondsQ10","DiamondsK10","Spades01","Spades02","Spades03","Spades04","Spades05","Spades06","Spades07","Spades08","Spades09","Spades10","SpadesJ10","SpadesQ10","SpadesK10","Clubs01","Clubs02","Clubs03","Clubs04","Clubs05","Clubs06","Clubs07","Clubs08","Clubs09","Clubs10","ClubsJ10","ClubsQ10","ClubsK10"]
    
    init(){
        cards.shuffle()
    }
    
    func countCards() -> Int{
        return cards.count
    }
    
    mutating func hit() -> String{
        return cards.removeFirst()
    }
}

struct Player{
    var hand = Array<String>()
    
    
    func countCards() -> Int{
        return hand.count
    }
    
    func handValue() -> Int{
        var value = 0
        for card in hand{
            value = value + Int(String(card.characters.suffix(2)))!
        }
        return value
    }
}
//#-end-hidden-code

class ViewController: UIViewController{
    //#-hidden-code
    let dealerView = UIView()
    let playerView = UIView()
    var pCardXPos = 60
    var dCardXPos = 60
    let pLabel = UILabel()
    let dLabel = UILabel()
    
    var myDeck: Deck = Deck()
    var myPlayer: Player = Player()
    var myDealer: Player = Player()
    
    override func viewDidLoad(){
        var myDeck: Deck = Deck()
        
        var myPlayer: Player = Player()
        var myDealer: Player = Player()
        
        createContainers()
        createLabel()
        createHitBtn(xPos: 195, yPos: 350, btnWidth:100, btnHeight:50)
        createClearBtn(xPos: 195, yPos: 450, btnWidth:100, btnHeight:50)
    }
    
    func createLabel(){
        pLabel.frame = CGRect(x:10, y:500, width: 490, height:50)
        pLabel.text = "Player's Value: " + String(myPlayer.handValue())
        self.view.addSubview(pLabel)
        
        dLabel.frame = CGRect(x:10, y:240, width: 490, height:50)
        dLabel.text = "Dealer's Value: " + String(myDealer.handValue())
        self.view.addSubview(dLabel)
    }
    
    func createContainers(){
        dealerView.frame = CGRect(x:10, y:10, width:490, height:240)
        dealerView.backgroundColor = UIColor.red
        dealerView.layer.cornerRadius = 25
        dealerView.layer.borderWidth = 0
        self.view.addSubview(dealerView)
        
        playerView.frame = CGRect(x:10, y:550, width:490, height:240)
        playerView.backgroundColor = UIColor.red
        playerView.layer.cornerRadius = 25
        playerView.layer.borderWidth = 0
        self.view.addSubview(playerView)
    }
    
    func createCard(player:Int, image:String, xPos: Int, yPos: Int){
        let img = UIImageView()
        
        img.image = UIImage(named: image)
        if player == 0{
            pCardXPos = xPos + 30
            img.frame = CGRect(x:pCardXPos, y:yPos, width:83, height:121)
            playerView.addSubview(img)
        } else {
            dCardXPos = xPos + 30
            img.frame = CGRect(x:pCardXPos, y:yPos, width:83, height:121)
            dealerView.addSubview(img)
        }
    }
    
    func createHitBtn(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        let button = UIButton()
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Hit", for:[])
        button.addTarget(self, action:#selector(hitAction), for: .touchUpInside)
        self.view.addSubview(button)
    }
    
    func createClearBtn(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        let button = UIButton()
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Clear", for:[])
        
        button.addTarget(self, action:#selector(clearAction), for: .touchUpInside)
        self.view.addSubview(button)
    }
    
    func removeSubviews(clearedView: UIView){
        for view in clearedView.subviews{
            UIView.animate(withDuration: 0.5, animations: {
                view.alpha = 0
                }, completion: {
                    _ in view.removeFromSuperview()
            })
        }
    }
    
    func clearAction(button:UIButton){
        
        myPlayer.hand.removeAll()
        myDealer.hand.removeAll()
        
        pLabel.text = "Player's Value: " + String(myPlayer.handValue())
        dLabel.text = "Dealer's Value: " + String(myDealer.handValue())
        
        removeSubviews(clearedView: playerView)
        removeSubviews(clearedView: dealerView)
        
        pCardXPos = 60
        dCardXPos = 60
    }
    
    //#-end-hidden-code
    func hitAction(button:UIButton){
        var card = ""
        
        //player card
        card = String(myDeck.hit())
        myPlayer.hand.append(card)
        createCard(player:0, image:card, xPos:pCardXPos, yPos:60)
        pLabel.text = "Player's Value: " + String(myPlayer.handValue())
        
        //dealer card
        //#-editable-code
        //#-end-editable-code
    }
//#-hidden-code
}
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
