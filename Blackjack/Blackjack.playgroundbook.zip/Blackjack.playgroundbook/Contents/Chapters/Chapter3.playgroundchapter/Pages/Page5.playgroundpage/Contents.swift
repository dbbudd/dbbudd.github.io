//: # Create Labels
//: Two global objects called `pLabel` and `dLabel` have been created in the view controller.  Inside the function called `createLabel()` define the properties of the two labels.
//: 1. pLabel must be 490x50 and be positioned in 10,500.  The text must be set to the value of `myPlayer.handValue()`
//: 2. dLabel must be 490x50 and be positioned in 10,240.  The text must be set to the value of 'myDealer.handValue()`
//: 3. add the labels to their respective Subviews
//:
//#-hidden-code
import PlaygroundSupport
import UIKit

extension Array{
    mutating func shuffle(){
        let length = Int(self.count)
        for _ in 0..<length{
            sort{
                (_,_) in arc4random() < arc4random()
            }
        }
    }
}

struct Deck{
    var cards = ["Hearts01","Hearts02","Hearts03","Hearts04","Hearts05","Hearts06","Hearts07","Hearts08","Hearts09","Hearts10","HeartsJ10","HeartsQ10","HeartsK10","Diamonds01","Diamonds02","Diamonds03","Diamonds04","Diamonds05","Diamonds06","Diamonds07","Diamonds08","Diamonds09","Diamonds10","DiamondsJ10","DiamondsQ10","DiamondsK10","Spades01","Spades02","Spades03","Spades04","Spades05","Spades06","Spades07","Spades08","Spades09","Spades10","SpadesJ10","SpadesQ10","SpadesK10","Clubs01","Clubs02","Clubs03","Clubs04","Clubs05","Clubs06","Clubs07","Clubs08","Clubs09","Clubs10","ClubsJ10","ClubsQ10","ClubsK10"]
    
    init(){
        cards.shuffle()
    }
    
    func countCards() -> Int{
        return cards.count
    }
    
    mutating func hit() -> String{
        return cards.removeFirst()
    }
}

struct Player{
    var hand = Array<String>()
    
    
    func countCards() -> Int{
        return hand.count
    }
    
    func handValue() -> Int{
        var value = 0
        for card in hand{
            value = value + Int(String(card.characters.suffix(2)))!
        }
        return value
    }
}
//#-end-hidden-code

class ViewController: UIViewController{
    let dealerView = UIView()
    let playerView = UIView()
    
    var myDeck: Deck = Deck()
    var myPlayer: Player = Player()
    var myDealer: Player = Player()
    
    let pLabel = UILabel() //already created pLabel for you
    let dLabel = UILabel() //already created dLabel for you

    override func viewDidLoad(){
        createContainers()
        createLabel()
    }
    

    
    func createLabel(){
        //#-editable-code
        //#-end-editable-code
    }
    
    func createContainers(){
        dealerView.frame = CGRect(x:10, y:10, width:490, height:240)
        dealerView.backgroundColor = UIColor.red
        dealerView.layer.cornerRadius = 25
        dealerView.layer.borderWidth = 0
        self.view.addSubview(dealerView)
        
        playerView.frame = CGRect(x:10, y:550, width:490, height:240)
        playerView.backgroundColor = UIColor.red
        playerView.layer.cornerRadius = 25
        playerView.layer.borderWidth = 0
        self.view.addSubview(playerView)
    }
}
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
