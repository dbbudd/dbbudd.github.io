//: # Create a container
//: The first thing we need to do in our new project is create a container which will hold our buttons and cards.
//: The `UIView()` object has already been created for you and you can see the `createContainer()` function is being called when the application loads.
//: Your job is to set the properties of the `newView`
//: 1. set the background colour to red.
//: 2. set the cornerRadius to 25.
//: 3. set the borderWidth to 0.
//:

//#-hidden-code
import PlaygroundSupport
import UIKit
//#-end-hidden-code
class ViewController: UIViewController{
    let newView = UIView()
    
    override func viewDidLoad(){
        createContainer()
    }
    
    func createContainer(){
        newView.frame = CGRect(x:10, y:10, width:490, height:240)
        //#-editable-code
        //#-end-editable-code
        self.view.addSubview(newView)
    }
    //#-end-hidden-code
}
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
