//: # Draw a random card
//: In this section we are going to draw a random card which will be represented by two values; the suit and the card.
//: 
//: 1. First, in the space below create a function called `drawRandomCard()` which will return two values.
//: 2. The first value is called `suit` is a **String** 
//: 3. The second is called `card` and is an **Int**
//: 4. Next create a constant called `suits` which contains a list of the possible suits e.g. "Diamonds, "Hearts", "Spades" and "Clubs"
//: 5. We then use the list index as a proxy and call a random number between 0 and 3.  This will give us a random suit which we can convert to a **String**.  The code will look like this: `let suit = String(suits(Int(arc4random_uniform(3))])`.
//: 6. For the card value create a new constant called `card` and set it to a random number between 1 and 13.
//: 7. Finally return suit and card.  `return (suit, card)`
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    //#-hidden-code
    let newView = UIView()
    let img1 = UIImageView()
    let img2 = UIImageView()
    
    override func viewDidLoad(){
        createContainer()
    }
    
    func createContainer(){
        newView.frame = CGRect(x:10, y:10, width:490, height:240)
        newView.backgroundColor = UIColor.red
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 0
        
        self.view.addSubview(newView)
        
        createImageHolders()
        createButton(xPos: 195, yPos: 90, btnWidth:100, btnHeight:50)
    }
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        let button = UIButton()
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        
        button.addTarget(self, action:#selector(buttonAction), for: .touchUpInside)
        newView.addSubview(button)
    }
    
    func createImageHolders(){
        
        img1.frame = CGRect(x:60, y:60, width:83, height:121)
        img2.frame = CGRect(x:347, y:60, width:83, height:121)
        
        img1.image = UIImage(named: "card_back")
        img2.image = UIImage(named: "card_back")
        
        newView.addSubview(img1)
        newView.addSubview(img2)
    }
    //#-end-hidden-code
    
    //#-editable-code
    
    //#-end-editable-code
        
//#-hidden-code
}
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
