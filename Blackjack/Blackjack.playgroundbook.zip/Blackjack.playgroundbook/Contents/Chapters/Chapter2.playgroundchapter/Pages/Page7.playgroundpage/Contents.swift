//: # You Lose!
//: Complete the function below called `checkWinner()`.  The function to produce a pop-up saying "You Lose!" if the value of the two cards is greater than "21".
//:
//: **Remember to convert your data types**
//:

//#-hidden-code
import PlaygroundSupport
import UIKit
//#-end-hidden-code

//#-hidden-code
class ViewController: UIViewController{
    
    let newView = UIView()
    let img1 = UIImageView()
    let img2 = UIImageView()
    
    override func viewDidLoad(){
        createContainer()
    }
    
    func createContainer(){
        newView.frame = CGRect(x:10, y:10, width:490, height:240)
        newView.backgroundColor = UIColor.red
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 0
        
        self.view.addSubview(newView)
        
        createImageHolders()
        createButton(xPos: 195, yPos: 90, btnWidth:100, btnHeight:50)
    }
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        let button = UIButton()
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        
        button.addTarget(self, action:#selector(buttonAction), for: .touchUpInside)
        newView.addSubview(button)
    }
    
    func createImageHolders(){
        
        img1.frame = CGRect(x:60, y:60, width:83, height:121)
        img2.frame = CGRect(x:347, y:60, width:83, height:121)
        
        img1.image = UIImage(named: "card_back")
        img2.image = UIImage(named: "card_back")
        
        newView.addSubview(img1)
        newView.addSubview(img2)
    }
    
    func drawRandomCard() -> (suit:String, card:Int){
        let suits = ["Diamonds", "Hearts", "Spades", "Clubs"]
        
        let suit = String(suits[Int(arc4random_uniform(3))])
        let card = Int(arc4random_uniform(13)+1)
        
        return (suit, card)
    }
    
    func buttonAction(){
        let card1 = drawRandomCard()
        let card2 = drawRandomCard()
        
        //display cards in image view
        if card1.card < 10{
            self.img1.image = UIImage(named: String(card1.suit) + "0" + String(card1.card))
        } else {
            self.img1.image = UIImage(named: String(card1.suit) + String(card1.card))
        }
        if card2.card < 10{
            self.img2.image = UIImage(named: String(card2.suit) + "0" + String(card2.card))
        } else {
            self.img2.image = UIImage(named: String(card2.suit) + String(card2.card))
        }
        
        //get the value of your current hand
        checkWinner(val1: card1.card, val2: card2.card)
    }
    //#-end-hidden-code
    
    func checkWinner(val1: Int, val2: Int){
        //#-editable-code
        let value = val1 + val2
        //#-end-editable-code
    }
//#-hidden-code
}
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
