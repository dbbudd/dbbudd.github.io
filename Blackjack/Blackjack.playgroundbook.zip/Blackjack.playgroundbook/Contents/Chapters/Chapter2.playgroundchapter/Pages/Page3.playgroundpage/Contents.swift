//: # Add an Image
//: Two global objects have already been declared for you inside the ViewController.  These are called `img1` and `img2`.
//:
//: 1. using `CGRect()` set the frame of `img1` to `(x:60, y:60, width:83, height:121)`
//: 2. now set the image property of `img1` to "card_back" this image has been included in the resources for you.
//: 3. using `CGRect()` set the frame of `img2` to `(x:347, y:60, width:83, height:121)`
//: 4. now set the image property of `img2` to "card_back" this image has been included in the resources for you.
//: 5. finally, add both `img1` and `img2` to the `newView` view. e.g. `newView.addSubview(img1)`
//:
//: If you have created the button correctly with the properties and commands listed above your two images should appear when you run the code and it will look like the image below.
//:
//: ![Screenshot](cards_screenshot.png)

//#-hidden-code
import PlaygroundSupport
import UIKit
//#-end-hidden-code
class ViewController: UIViewController{
    
    let newView = UIView()
    let img1 = UIImageView()
    let img2 = UIImageView()
    
    //#-hidden-code
    override func viewDidLoad(){
        createContainer()
    }
    
    func createContainer(){
        newView.frame = CGRect(x:10, y:10, width:490, height:240)
        newView.backgroundColor = UIColor.red
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 0
        
        self.view.addSubview(newView)
        
        createImageHolders()
    }
    //#-end-hidden-code
    
    func createImageHolders(){
        //#-editable-code
        //#-end-editable-code
    }
}
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
