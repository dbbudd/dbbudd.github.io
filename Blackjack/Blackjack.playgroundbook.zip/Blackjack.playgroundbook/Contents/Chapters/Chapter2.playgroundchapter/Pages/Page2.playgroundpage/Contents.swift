//: # Add cards
//: Now we are going to create two global objects which will eventually show images of our cards as we draw them.  These objects are global so that they can be accessed and manipulated from any of the functions within our ViewController class.
//: The objects should be called `img1` and `img2` respectively and they should be instances of `UIImageView()` objects.
//:

//#-hidden-code
import PlaygroundSupport
import UIKit
//#-end-hidden-code
class ViewController: UIViewController{
    
    let newView = UIView()
    //#-editable-code
    //#-end-editable-code
    
    //#-hidden-code
    override func viewDidLoad(){
        createContainer()
    }
    
    func createContainer(){
        newView.frame = CGRect(x:10, y:10, width:490, height:240)
        newView.backgroundColor = UIColor.red
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 0
        
        self.view.addSubview(newView)
        
    }
    //#-end-hidden-code
}
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
