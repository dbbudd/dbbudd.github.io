//: # Button Action
//: Once we are successfully "drawing a random card" we can apply a button action which will get the related image and put in into the placeholder.
//:
//: Currently `image` property of `img1` and `img2` are set to "card_back".  You can see from the image below that this is the name of the image at the top of the list in the resources.   The name of the other cards are a combination of the `card.suit` and `card.card`.  If the number is less then 10, you will also need to add a "0" as a prefix.
//:
//: ![Resource list](Resources.png)
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    //#-hidden-code
    let newView = UIView()
    let img1 = UIImageView()
    let img2 = UIImageView()
    
    override func viewDidLoad(){
        createContainer()
    }
    
    func createContainer(){
        newView.frame = CGRect(x:10, y:10, width:490, height:240)
        newView.backgroundColor = UIColor.red
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 0
        
        self.view.addSubview(newView)
        
        createImageHolders()
        createButton(xPos: 195, yPos: 90, btnWidth:100, btnHeight:50)
    }
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        let button = UIButton()
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        
        button.addTarget(self, action:#selector(buttonAction), for: .touchUpInside)
        newView.addSubview(button)
    }
    
    func createImageHolders(){
        
        img1.frame = CGRect(x:60, y:60, width:83, height:121)
        img2.frame = CGRect(x:347, y:60, width:83, height:121)
        
        img1.image = UIImage(named: "card_back")
        img2.image = UIImage(named: "card_back")
        
        newView.addSubview(img1)
        newView.addSubview(img2)
    }
    
    func drawRandomCard() -> (suit:String, card:Int){
        let suits = ["Diamonds", "Hearts", "Spades", "Clubs"]
        
        let suit = String(suits[Int(arc4random_uniform(3))])
        let card = Int(arc4random_uniform(13)+1)
        
        return (suit, card)
    }
    //#-end-hidden-code
    
    func buttonAction(){
        
        let card1 = drawRandomCard()
        let card2 = drawRandomCard()
        
        //#-editable-code
        if card1.card < 10{
            self.img1.image = UIImage(named: "card_back")
        } else {
            self.img1.image = UIImage(named: "card_back")
        }
        if card2.card < 10{
            self.img2.image = UIImage(named: "card_back")
        } else {
            self.img2.image = UIImage(named: "card_back")
        }
        //#-end-editable-code
    }
//#-hidden-code
}
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
