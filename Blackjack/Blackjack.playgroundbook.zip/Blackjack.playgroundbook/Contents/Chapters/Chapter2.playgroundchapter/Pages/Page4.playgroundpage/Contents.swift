//: # Create a Button
//: 1. create a function called `createButton()`
//: 2. the button must have the following four parameters: `(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double)`
//: 3. the `backgroundColor` property should be set to `UIColor.black`
//: 4. the `cornerRadius` should be set to 10.
//: 5. the 'setTitle' property should display the string "Press Me".
//: 6. set the target of the button to the following line of code. `button.addTarget(self, action:#selector(buttonAction), for: .touchUpInside)`
//: 7. finally, `add` the button to `newView`. e.g. `newView.addSubview(button)`
//:
//: If you have created the button correctly with the properties and commands listed above your button should appear when you run the code.
//:
//: ![Screenshot](cards_screenshot.png)

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    //#-hidden-code
    let newView = UIView()
    let img1 = UIImageView()
    let img2 = UIImageView()
    
    override func viewDidLoad(){
        createContainer()
    }
    
    func createContainer(){
        newView.frame = CGRect(x:10, y:10, width:490, height:240)
        newView.backgroundColor = UIColor.red
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 0
        
        self.view.addSubview(newView)
        
        createImageHolders()
        createButton(xPos: 195, yPos: 90, btnWidth:100, btnHeight:50)
    }
    
    func createImageHolders(){
        
        img1.frame = CGRect(x:60, y:60, width:83, height:121)
        img2.frame = CGRect(x:347, y:60, width:83, height:121)
        
        img1.image = UIImage(named: "card_back")
        img2.image = UIImage(named: "card_back")
        
        newView.addSubview(img1)
        newView.addSubview(img2)
    }
    //#-end-hidden-code
    
    //#-editable-code
    
    //#-end-editable-code
    
//#-hidden-code
}
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
//: [Previous](@previous)  ||  [Next Topic](@next)
