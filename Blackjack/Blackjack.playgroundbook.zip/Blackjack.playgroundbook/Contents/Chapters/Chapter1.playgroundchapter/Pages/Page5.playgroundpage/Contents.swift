//: # Create a Label
//: Labels can be created in a very similar manner to buttons and they also have very similar properties.  
//:
//: A new instance of the `UILabel()` object has been created in the view controller below and a function as been created called `createLabel()` which defines the label's properties.  You must modify the label properties in the `buttonAction()` function to increase the number of the label by "2" each time the button is pressed.
//:
//: ## Hint
//: You will need to convert the data types because a lable will only display values as a `String()` .

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    //#-end-hidden-code
    
    let button = UIButton()
    let label = UILabel()
    
    override func viewDidLoad(){
        
        createButton(xPos: 100, yPos: 100, btnWidth: 100, btnHeight: 50)
        createLabel(lblText: "0")
    }
    
    func createLabel(lblText: String){
        label.frame = CGRect(x: 100, y:250, width: 100, height: 50)
        label.text = lblText
        self.view.addSubview(label)
    }
    
    func buttonAction(){
        //#-editable-code
        //#-end-editable-code
    }
    
    //#-hidden-code
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
    }
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

//: [Previous](@previous)  ||  [Next Topic](@next)
