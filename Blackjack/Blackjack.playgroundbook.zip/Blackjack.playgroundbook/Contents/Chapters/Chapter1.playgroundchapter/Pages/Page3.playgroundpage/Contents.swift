//: # Create a Action
//: We are now going to make our button action a little more interesting.  Inside the `buttonAction()` write some logic which will check if the `button.backgroundColor == UIColor.black()` , if it is then switch the colour to yellow.
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
//#-end-hidden-code
    
    let button = UIButton()
    
    override func viewDidLoad(){
        
        createButton(xPos: 100, yPos: 100, btnWidth: 100, btnHeight: 50)
    }
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
    }
    
    func buttonAction(){
        //#-editable-code
        //#-end-editable-code
    }

//#-hidden-code
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

//: [Previous](@previous)  ||  [Next Topic](@next)
