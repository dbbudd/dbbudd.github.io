//: # Create a Slider
//: The function below `createSlider()` creates a slider and shows you some of the properties which can be manipulated.  In the `sliderAction()` function set the text in the label to the value of the slider.
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    //#-end-hidden-code
    //#-hidden-code
    let button = UIButton()
    let label = UILabel()
    let slider = UISlider()
    
    override func viewDidLoad(){
        
        //createButton(xPos: 100, yPos: 100, btnWidth: 100, btnHeight: 50)
        createLabel()
        createSlider(xPos: 100, yPos: 350)
    }
    
    func createLabel(){
        label.frame = CGRect(x: 100, y:250, width: 100, height: 50)
        label.text = String(slider.value)
        self.view.addSubview(label)
    }
    //#-end-hidden-code
    
    func createSlider(xPos: Double, yPos: Double){
        slider.frame = CGRect(x:xPos, y:yPos, width: 200, height:50)
        slider.minimumValue = 0
        slider.maximumValue = 200
        slider.value = 100
        slider.isContinuous = true
        slider.tintColor = UIColor.blue
        slider.maximumTrackTintColor = UIColor.yellow
        slider.isUserInteractionEnabled = true
        
        slider.addTarget(self, action:#selector(sliderAction), for: .valueChanged)
        self.view.addSubview(slider)
    }
    
    func sliderAction(){
        //#-editable-code
        //#-end-editable-code
    }
    //#-hidden-code
    func buttonAction(){
        //#-editable-code
        //#-end-editable-code
    }
    //#-end-hidden-code
    
    //#-hidden-code
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
    }
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

//: [Previous](@previous)  ||  [Next Topic](@next)

