//: # Create a View
//: The easiest way to align or group objects is to put them into their own view.  This allows you to control or manipulate them as a group.
//:
//: Notice that the `createButton()` function is now called inside the `createView()` function and the x and y coordinates are relative to the inside of the view.  You can also see that instead of:
//:
//: `self.view.addSubview(button)`
//:
//: The following line of code is used to add the button to the subview:
//:
//: `newView.addSubview(button)`
//:
//:
//: **Play with manipulating the properties of the `newView`.**
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    let button = UIButton()
    let label = UILabel()
    let newView = UIView()
    
    override func viewDidLoad(){
        createLabel()
        createView()
    }
    
    func createLabel(){
        label.frame = CGRect(x: 100, y:250, width: 100, height: 50)
        label.text = "My Label"
        self.view.addSubview(label)
    }
    //#-end-hidden-code
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        
        newView.addSubview(button)
    }
    
    func createView(){
        //#-editable-code
        newView.frame = CGRect(x:100, y: 400, width: 300, height: 200)
        newView.backgroundColor = UIColor.green
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 2
        //#-end-editable-code
        self.view.addSubview(newView)
        createButton(xPos: 20, yPos: 20, btnWidth: 100, btnHeight: 50)
    }
    
    //#-hidden-code
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

//: [Previous](@previous)  ||  [Next Topic](@next)

