//: # Create a Button
//: Buttons are just one of the objects which you can utilise in `UIKit`, they are also fundamental to building an interface.
//:
//: In the code below you can see we have created a new instance of the object `UIButton` and we have defined the position (x,y) and size (width, height) using `CGRect`.  We then manipulate the properties of the buttons and create an action for when the button is pressed.  The final line of code adds the button to our ViewController, this is VERY important and often gets forgotten.
//:
//: Create your own button in a function called `createButton()` which is defined outside of `viewDidLoad()`.  
//: * The function should have parameters to define its position, size and title.  
//: * The button should call the same `buttonAction()` function when pressed.  
//: * Once you have created your it should be called inside `viewDidLoad()`
//:
//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
//#-end-hidden-code
    override func viewDidLoad(){
        let button = UIButton(frame: CGRect(x:100, y:100, width:100, height:50))
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
        
        //#-editable-code
        //call your function here
        //#-end-editable-code
    }
    
    //#-editable-code
    //Create a function to generate a button
    //#-end-editable-code
    
    func buttonAction(){
        print("Button was pressed")
    }
//#-hidden-code
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

//: [Previous](@previous)  ||  [Next Topic](@next)
