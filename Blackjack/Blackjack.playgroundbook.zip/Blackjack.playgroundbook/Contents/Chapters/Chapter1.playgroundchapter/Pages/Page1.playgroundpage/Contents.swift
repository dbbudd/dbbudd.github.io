//#-hidden-code
import PlaygroundSupport
//#-end-hidden-code
//: # Introduction to UIKit
//: UIKit includes all of the of the objects which users interact with in applications; Buttons, Labels, Sliders, Views and Images.  Through these exercises you will familiarise yourself with these objects and their properties.
//:
//: We begin by importing UIKit into the project. You will see that there is a main ViewController class which is subclass of UIViewController.  We also have our main method called `viewDidLoad()`.  Anything within this method will be called when the application is first run.
//:


import UIKit

class ViewController: UIViewController{
    override func viewDidLoad(){
        //code run when loaded
    }
    
}


//: [Previous](@previous)  ||  [Next Topic](@next)
//#-hidden-code
PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code
