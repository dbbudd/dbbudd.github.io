//: # Pop-up
//: We are now going to modify our `buttonAction()` to create a pop-up window when we click the button.
//:
//: Modify the title and message in the pop-up box.
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
//#-end-hidden-code
    //#-hidden-code
    let button = UIButton()
    
    override func viewDidLoad(){
        
        createButton(xPos: 100, yPos: 100, btnWidth: 100, btnHeight: 50)
    }
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
    }
    //#-end-hidden-code
    func buttonAction(){
        //#-editable-code
        let alert = UIAlertController(title:"Hello World", message: "Check out my pop-up!", preferredStyle:.alert)
        let action = UIAlertAction(title:"OK", style:.default, handler:nil)
        
        alert.addAction(action)
        present(alert, animated:true, completion:nil)
        //#-end-editable-code
    }
    
//#-hidden-code
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

//: [Previous](@previous)  ||  [Next Topic](@next)
