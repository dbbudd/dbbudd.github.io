//: # Move the Label
//: Edit the `createLabel()` function to move the label into the `newView`.
//:

//#-hidden-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    let button = UIButton()
    let label = UILabel()
    let newView = UIView()
    
    override func viewDidLoad(){
        createView()
    }
    //#-end-hidden-code
    
    func createLabel(){
        //#-editable-code
        label.frame = CGRect(x: 100, y:250, width: 100, height: 50)
        label.text = "My Label"
        
        self.view.addSubview(label)
        //#-end-editable-code
    }
    
    func createButton(xPos:Double, yPos:Double, btnWidth:Double, btnHeight:Double){
        button.frame = CGRect(x:xPos, y:yPos, width:btnWidth, height:btnHeight)
        button.backgroundColor = UIColor.black
        button.layer.cornerRadius = 10
        button.setTitle("Press Me", for:[])
        
        newView.addSubview(button)
    }
    
    func createView(){
        newView.frame = CGRect(x:100, y: 400, width: 300, height: 200)
        newView.backgroundColor = UIColor.green
        newView.layer.cornerRadius = 25
        newView.layer.borderWidth = 2
        
        self.view.addSubview(newView)
        createLabel()
        createButton(xPos: 20, yPos: 20, btnWidth: 100, btnHeight: 50)
    }
    
    //#-hidden-code
}

PlaygroundPage.current.liveView = ViewController()
//#-end-hidden-code

//: [Previous](@previous)  ||  [Next Topic](@next)

